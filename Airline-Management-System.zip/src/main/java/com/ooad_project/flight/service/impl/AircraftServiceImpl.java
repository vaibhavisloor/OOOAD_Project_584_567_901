package com.ooad_project.flight.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.ooad_project.flight.model.Aircraft;
import com.ooad_project.flight.repository.AircraftRepository;
import com.ooad_project.flight.service.AircraftService;

@Service
@Transactional
public class AircraftServiceImpl implements AircraftService {

	private final AircraftRepository aircraftRepository;

	@Autowired
	public AircraftServiceImpl(AircraftRepository aircraftRepository) {
		this.aircraftRepository = aircraftRepository;
	}

	@Override
	public Page<Aircraft> getAllAircraftsPaged(int pageNum) {
		return aircraftRepository.findAll(PageRequest.of(pageNum, 10));
	}

	@Override
	public List<Aircraft> getAllAircrafts() {
		return aircraftRepository.findAll();
	}

	@Override
	public Aircraft getAircraftById(Long aircraftId) {
		return aircraftRepository.findById(aircraftId)
				.orElseThrow(() -> new RuntimeException("Aircraft not found with id " + aircraftId));
	}

	@Override
	public Aircraft saveAircraft(Aircraft aircraft) {
		return aircraftRepository.save(aircraft);
	}

	@Override
	public void deleteAircraftById(Long aircraftId) {
		aircraftRepository.deleteById(aircraftId);
	}
}
