package com.ooad_project.flight.controller;

import javax.validation.Valid;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ooad_project.flight.model.Airport;
import com.ooad_project.flight.service.AirportService;

@Controller
public class AirportController {

	@Autowired
	private AirportService airportService;

	private final Invoker invoker = new Invoker();

	@GetMapping("/airport/new")
	public String showAddAirportPage(Model model) {
		Command showAddAirportPageCommand = new ShowAddAirportPageCommand();
		invoker.setCommand(showAddAirportPageCommand);
		return invoker.executeCommand(model);
	}

	@PostMapping("/airport/new")
	public String saveAirport(@Valid @ModelAttribute("airport") Airport airport, BindingResult bindingResult,
							  Model model) {
		Command saveAirportCommand = new SaveAirportCommand(airport, bindingResult, airportService);
		invoker.setCommand(saveAirportCommand);
		return invoker.executeCommand(model);
	}

	@GetMapping("/airports")
	public String showAirportsList(@RequestParam(defaultValue = "0") int pageNo, Model model) {
		Command showAirportsListCommand = new ShowAirportsListCommand(pageNo, airportService);
		invoker.setCommand(showAirportsListCommand);
		return invoker.executeCommand(model);
	}

	private static class Invoker {
		private Command command;

		public void setCommand(Command command) {
			this.command = command;
		}

		public String executeCommand(Model model) {
			return command.execute(model);
		}
	}

	private interface Command {
		String execute(Model model);
	}

	private static class ShowAddAirportPageCommand implements Command {
		@Override
		public String execute(Model model) {
			model.addAttribute("airport", new Airport());
			return "newAirport";
		}
	}

	private static class SaveAirportCommand implements Command {
		private final Airport airport;
		private final BindingResult bindingResult;
		private final AirportService airportService;

		public SaveAirportCommand(Airport airport, BindingResult bindingResult, AirportService airportService) {
			this.airport = airport;
			this.bindingResult = bindingResult;
			this.airportService = airportService;
		}

		@Override
		public String execute(Model model) {
			if (bindingResult.hasErrors()) {
				model.addAttribute("errors", bindingResult.getAllErrors());
				model.addAttribute("airport", new Airport());
				return "newAirport";
			}
			airportService.saveAirport(airport);
			model.addAttribute("airports", airportService.getAllAirportPaged(0));
			model.addAttribute("currentPage", 0);
			return "airports";
		}
	}

	private static class ShowAirportsListCommand implements Command {
		private final int pageNo;
		private final AirportService airportService;

		public ShowAirportsListCommand(int pageNo, AirportService airportService) {
			this.pageNo = pageNo;
			this.airportService = airportService;
		}

		@Override
		public String execute(Model model) {
			model.addAttribute("airports", airportService.getAllAirportPaged(pageNo));
			model.addAttribute("currentPage", pageNo);
			return "airports";
		}
	}
}