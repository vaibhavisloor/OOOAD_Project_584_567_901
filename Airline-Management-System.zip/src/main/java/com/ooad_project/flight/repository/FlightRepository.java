package com.ooad_project.flight.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ooad_project.flight.model.Airport;
import com.ooad_project.flight.model.Flight;

public interface FlightRepository extends JpaRepository<Flight, Long> {

	public List<Flight> findAllByDepartureAirportEqualsAndDestinationAirportEqualsAndDepartureDateEquals(
			Airport departureAirport, Airport destinationAirport, LocalDate departureDate);
}
//Finds flights