package com.ooad_project.flight.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ooad_project.flight.model.Aircraft;

public interface AircraftRepository extends JpaRepository<Aircraft, Long> {

}
