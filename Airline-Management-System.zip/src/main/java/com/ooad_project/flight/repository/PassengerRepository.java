package com.ooad_project.flight.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ooad_project.flight.model.Passenger;

public interface PassengerRepository extends JpaRepository<Passenger, Integer> {

}
